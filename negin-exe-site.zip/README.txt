NEGIN.EXE
یک سایت تک‌فایلی، بدون نیاز به کدنویسی یا نصب.

انتشار سریع:
1) وارد https://app.netlify.com/drop شوید.
2) فایل index.html را داخل صفحه بکشید و رها کنید.
3) Netlify یک لینک رایگان با دامنه netlify.app می‌دهد.

برای تغییر متن‌ها، index.html را با Notepad باز کنید.
